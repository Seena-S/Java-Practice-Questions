package com.demo.test.Model.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.demo.test.DTO.UserDTO;
import com.demo.test.Model.DAO.UserDAO;
@Service
public class UserService {
	
	private UserDAO dao;
	public void addUserService(UserDTO dto){
		dao.addUser(dto);
	}
	public List<UserDTO> getAllUsersService(){
		return dao.getAllUsers();
		
	}
	

}
