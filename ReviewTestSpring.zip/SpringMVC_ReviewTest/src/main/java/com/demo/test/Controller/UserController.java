package com.demo.test.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.test.DTO.UserDTO;
import com.demo.test.Model.Service.UserService;


@Controller
public class UserController {
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public ModelAndView addUserController(@ModelAttribute UserDTO dto) {
		service.addUserService(dto);
		return new ModelAndView("redirect:/viewUser.jsp");
	}

}
