package com.demo.test.Model.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.test.DTO.UserDTO;
@Repository
public class UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public void addUser(UserDTO dto) {
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(dto);
		transaction.commit();
		session.close();
		
	}
	
	public List<UserDTO> getAllUsers(){
		Session session=sessionFactory.openSession();
		List<UserDTO> users=  (List<UserDTO>)session.createQuery("from UserDTO").list();
		session.close();
		return users;
	}

}
