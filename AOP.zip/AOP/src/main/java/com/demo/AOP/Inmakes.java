package com.demo.AOP;

import org.springframework.stereotype.Component;

@Component
public class Inmakes {
	
	public void displayCourses() {
		System.out.println("Displaying all courses..");
	}

}
